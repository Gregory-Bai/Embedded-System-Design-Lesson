/**********************************************************************

This is a new blank project with necessary hardware support files only.

-- SystemStartUp: Include basic and necessary hardware support files
                  for STM32F103C8T6.
-- User: User program

***********************************************************************
Author: Gregory Bai
Date: 28 Feb. 2024
***********************************************************************/

#include "stm32f10x.h"                  // Device header

int main(void)
{
	while (1)
	{
	
	}
}


